from cost import *
from azure_rest.token import *
from metrics import *


def main():
    pass

if __name__ == "__main__":
  main()
